
// Extensión Paste JSON as Code
// https://pokeapi.co/



