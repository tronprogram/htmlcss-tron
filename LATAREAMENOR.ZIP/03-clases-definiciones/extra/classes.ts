export class SuperHeroe {

    nombre: string;
    poder: string;
    edad: number;
    pasatiempo: string;

    constructor() { }

    usarPoder() {}

    volar() {}

    correr() {}

    caminar() {}

    revivir() {}

}
