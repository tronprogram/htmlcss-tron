/*
    Objetivo:
        Deshacer y rehacer el código
§
    Tips:
        ⌘ Z
        ⌘ ⇧ Z
        Ctrl +Z
        Ctrl + Shift + Z

*/

function holaMundo(){
    return 'saludos a todos!'
}




// Demo
// function holaMundo() {
//     return 'Saludos a todos!';
// }


// Done!!