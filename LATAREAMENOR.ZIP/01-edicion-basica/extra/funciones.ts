


export function saludar1( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar2( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar3( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar4( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar5( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar6( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar7( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar8( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar9( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar10( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar11( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar12( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar13( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar14( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar15( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar16( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar( nombre: string ) {
    return `Hola ${ nombre }!!!`;
}

export function saludar17( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar18( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar19( nombre: string ) {
    return `Yo no hago nada!!!`;
}

export function saludar20( nombre: string ) {
    return `Yo no hago nada!!!`;
}



